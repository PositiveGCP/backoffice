Secca Soft - Free Test Package from www.astype.de

files included:
-------------------
specimen/astypelibrary.pdf	- astype font catalog file
specimen/SeccaSeries_spec.pdf	- Secca Series specimen file
SeccaSoft-Pro-080-It.otf	- Secca Soft Italic / font file
SeccaSoft-Pro-084-Rg.otf	- Secca Soft Regular / font file
SeccaSoft-Pro-136-Bd-It.otf	- Secca Soft Bold Italic / font file
SeccaSoft-Pro-142-Bd.otf	- Secca Soft Bold / font file
astype_license_EULA.txt		- astype license file
ReadMe.txt			- this file


These fonts are free for commercial and personal use as long as you downloaded the fonts from astype.de or astype.com.
No redistribution allowed!

By downloading these fonts you agreed to the astype standard End User License Agreement (EULA). The EULA is available from file
(astype_license_EULA.txt) or from the astype website. www.astype.de/license

If you do not agree with such Agreement delete all font files from the package!